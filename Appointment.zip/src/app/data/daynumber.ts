export interface IDayNumber{
    dayNumber:number;
    
}