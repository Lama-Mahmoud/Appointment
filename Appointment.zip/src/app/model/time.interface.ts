export interface ITime
{
    reserved:boolean,
    time: String;
}
/*
this interface is use to create a list of time slot that will push them to a map in appointment interface(IAppointmentDay)
also this use for a demo data
*/