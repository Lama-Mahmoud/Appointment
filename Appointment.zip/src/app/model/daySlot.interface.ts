import { ITime } from "./time.interface";

export interface IDaySlot{
    dayTimeList:Array<ITime>;
}