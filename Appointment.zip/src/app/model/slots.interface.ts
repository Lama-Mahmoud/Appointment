export interface ISlots
{
    available2 : string;
}
