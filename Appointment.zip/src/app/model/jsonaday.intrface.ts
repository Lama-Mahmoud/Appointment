export interface jsonaday{
  day:Number,
  enable:Boolean,
  availableSlot:Number,
}